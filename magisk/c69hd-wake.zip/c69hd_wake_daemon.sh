#!/system/bin/sh
# Onyx Boox C69HD Hardware Button Wake & Double Tap to Wake Daemon
# Running as background service via Magisk

DAEMON_LOG="/data/local/tmp/c69hd_wake.log"
echo "=== C69HD Wake Daemon started: $(date) ===" > "$DAEMON_LOG"

# 1. Enable Double Tap to Wake in FocalTech touch driver
if [ -f /sys/devices/platform/soc/4a88000.i2c/i2c-1/1-0008/fts_gesture_mode ]; then
    echo 1 > /sys/devices/platform/soc/4a88000.i2c/i2c-1/1-0008/fts_gesture_mode
    echo "FTS gesture mode armed." >> "$DAEMON_LOG"
fi

# Function to wake screen if asleep
wake_device() {
    reason="$1"
    if ! dumpsys power | grep -q 'mWakefulness=Awake'; then
        echo "[WAKE] Screen is asleep. Waking via $reason at $(date)" >> "$DAEMON_LOG"
        sendevent /dev/input/event0 1 116 1
        sendevent /dev/input/event0 0 0 0
        sendevent /dev/input/event0 1 116 0
        sendevent /dev/input/event0 0 0 0
    else
        echo "[IGNORE] Event ($reason) received but screen is already awake." >> "$DAEMON_LOG"
    fi
}

# Worker 1: Monitor physical center button on /dev/input/event0 (scancode 158 / 0x9e)
monitor_center_button() {
    getevent /dev/input/event0 | while read -r line; do
        case "$line" in
            *"0001 009e 00000001"*)
                wake_device "CenterButton(158)"
                ;;
        esac
    done
}

# Worker 2: Monitor physical side page-turn buttons on /dev/input/event3 (scancodes 104 / 109)
monitor_side_buttons() {
    if [ -e /dev/input/event3 ]; then
        getevent /dev/input/event3 | while read -r line; do
            case "$line" in
                *"0001 0068 00000001"*|*"0001 006d 00000001"*)
                    wake_device "SideButton"
                    ;;
            esac
        done
    fi
}

# Worker 3: Monitor Double Tap to Wake via dmesg -w
monitor_dt2w() {
    last_tap=0
    dmesg -w | while read -r line; do
        case "$line" in
            *"invalid point_num(15)"*)
                # Only process if asleep
                if ! dumpsys power | grep -q 'mWakefulness=Awake'; then
                    now_ms=$(date +%s%N | cut -c 1-13)
                    diff=$((now_ms - last_tap))
                    echo "[TAP] Screen touched in sleep at $now_ms (diff: ${diff}ms)" >> "$DAEMON_LOG"
                    if [ "$diff" -gt 80 ] && [ "$diff" -lt 800 ]; then
                        wake_device "DoubleTap(${diff}ms)"
                        last_tap=0
                    else
                        last_tap=$now_ms
                    fi
                fi
                ;;
        esac
    done
}

# Launch all monitors in background
monitor_center_button &
PID_CENTER=$!

monitor_side_buttons &
PID_SIDE=$!

monitor_dt2w &
PID_DT2W=$!

echo "Monitors launched: Center(PID $PID_CENTER), Side(PID $PID_SIDE), DT2W(PID $PID_DT2W)" >> "$DAEMON_LOG"

# Wait for children
wait
